using System.Collections.Generic;
using System.Linq;

namespace BPM.Core.Nodes.Evaluation;

public class GroupNodeStateEvaluator(INode node) : INodeStateEvaluator
{
    private List<(bool isComplete, List<INode> availableNodes)>? _subNodesCompletionStates;

    public bool IsCompleted(List<object> storedEvents)
    {
        if (node is GroupNode groupNode)
        {
            if (_subNodesCompletionStates is null)
            {
                _subNodesCompletionStates = new List<(bool isComplete, List<INode> availableNodes)>();
                groupNode.SubRootNodes.ForEach(x => { _subNodesCompletionStates.Add(x.GetCheckBranchCompletionAndGetAvailableNodesFromCache(storedEvents)); });
            }

            return _subNodesCompletionStates.All(x => x.isComplete);
        }

        return false;
    }

    public (bool, List<INode>) CanExecute(INode rootNode, List<object> storedEvents)
    {
        bool canExecute = !rootNode.NextSteps?.Where(z => z.CommandType != node.CommandType).Any(x => x.ContainsEvent(storedEvents)) ?? true;
        if (canExecute)
        {
            if (node.PrevSteps?.All(x => x is not null) ?? false)
            {
                canExecute = Helpers.FindFirstNonOptionalCompletion(node.PrevSteps, storedEvents) ?? true;
                if (!canExecute)
                    return (false, []);
            }

            if (node is GroupNode groupNode)
            {
                List<INode> result = [];

                if (_subNodesCompletionStates is null)
                {
                    _subNodesCompletionStates = new List<(bool isComplete, List<INode> availableNodes)>();
                    groupNode.SubRootNodes.ForEach(x => { _subNodesCompletionStates.Add(x.GetCheckBranchCompletionAndGetAvailableNodesFromCache(storedEvents)); });
                }

                result.AddRange(_subNodesCompletionStates.SelectMany(x => x.availableNodes));
                return (canExecute, result);
            }

            return (false, []);
        }

        return (false, []);
    }
}
